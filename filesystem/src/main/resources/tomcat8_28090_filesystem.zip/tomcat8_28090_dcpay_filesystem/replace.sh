

tomcat_root=`pwd`
project_name=dcpay_business
project_run_name=dcpay_business

$tomcat_root/bin/shutdown.sh && \
sleep 1 & kill -9 `jps -v | grep $tomcat_root|awk '{print $1}'` && \
rm -rf webapps/* && mv $project_name.war webapps/$project_run_name.war && \
$tomcat_root/bin/startup.sh && \
tail -f $tomcat_root/logs/catalina.out



